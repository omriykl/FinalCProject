Linux instructions:
-------------------
1. put all files in the project root folder
2. run command:
   python test.py ./SPCBIR -c test1.config

NOTE: the program should take around 2-3 minutes to complete

3. check HTML (back in windows) for results

HAVE FUN!